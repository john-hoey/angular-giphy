import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-favs',
  templateUrl: './search-favs.component.html',
  styleUrls: ['./search-favs.component.css']
})
export class SearchFavsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
